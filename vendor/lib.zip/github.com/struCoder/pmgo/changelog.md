### v0.5.1
- fix bug: when first install pmgo with `install.sh`. thanks to @sanqi

### v0.5.0

- feature: pmgo daemon will auto start
- fix bugs

### v0.2.0

- use [tablewrite](github.com/olekukonko/tablewriter) instead of PadString format
- add feature: `pmgo info procname` get proc detail info
